"""§4.8-§4.9 — D-1 (reverse math · proof theory · ordinals · model theory · computability · descriptive set
theory) and D-2 (computational complexity · higher categories/HoTT). D-1·D-2 confirmed the framework is CLOSED:
no 15th mechanism (cut-elim = purest M13; univalence = M9 definitional; SOS = M4+M14; sum-check = M2+M7;
PCP = M8+error-correction; GCT = M9+symmetry; diagonal/fixpoint lemma = ur-form of M1·M14)."""
from catalog.base import Transform as T, reg_many

_EXIST = "UNVERIFIED(existing impl; catalog-gate wiring pending)"
_NEW = "UNVERIFIED(registered; sound apply gated in a later PHASE)"

reg_many([
    # D-1
    T("D1.big_five_reversal", "D-1", "reverse-math", (9,), "finite-invariant", "reversal",
      "theorem / proof", "Coq/Lean (reversal, 5-class strength)", "DECISION", _NEW),
    T("D1.proof_theoretic_ordinal", "D-1", "proof-theory", (9,), "ordinal-rank", "ordinal_analysis",
      "formal theory", "|PA|=ε₀, |ATR₀|=Γ₀, |Π¹₁-CA₀|=ψ₀(Ω_ω) (Bachmann–Howard is KPω/ID₁ — corrected)",
      "DECISION", _NEW),
    T("D1.cut_elimination", "D-1", "proof-theory", (8, 13), "normal-form", "cut_free",
      "proof term", "Coq/Lean/Agda kernel [haran_coq, proof_checker]", "EXACT", _EXIST),
    T("D1.ordinal_termination", "D-1", "proof-theory", (14,), "ordinal-rank", "ordinal_decreases",
      "recursive measure (fold decreases-clause)", "[이미 있음: ordinal, measure_synth] (★ §8 PHASE C)", "EXACT", _EXIST),
    T("D1.dialectica_mining", "D-1", "proof-theory", (4,), "cert-bound", "explicit_bound",
      "Π⁰₂ theorem (non-constructive)", "Kohlenbach proof mining", "DECISION", _NEW),
    T("D1.presburger_qe", "D-1", "logic", (2, 3), "decision", "qe_equivalence",
      "(ℤ,+,<) formula", "z3/isl/Cooper [bitblast_smt, z3_adapter] (★ §8 PHASE B)", "EXACT", _EXIST),
    T("D1.rcf_cad_qe", "D-1", "logic", (2, 3), "decision", "qe_equivalence",
      "real-closed-field polynomial formula", "QEPCAD-B/Redlog [이미 있음: mathmode/real_qe] (★ §8)", "EXACT", _EXIST),
    T("D1.acf_qe", "D-1", "logic", (2,), "decision", "qe_equivalence",
      "algebraically-closed-field formula (Chevalley)", "ACF QE", "EXACT", _NEW),
    T("D1.stability_urank", "D-1", "model-theory", (9,), "ordinal-rank", "u_rank",
      "first-order theory model", "Morley/U-rank", "DECISION", _NEW),
    T("D1.ominimal_cell", "D-1", "model-theory", (10, 2), "finite-invariant", "cell_decomposition",
      "tame structure (special points)", "Pila–Wilkie", "DECISION", _NEW),
    T("D1.arithmetic_hierarchy", "D-1", "computability", (9,), "finite-invariant", "hierarchy_position",
      "predicate definability (Σ⁰ₙ/Π⁰ₙ)", "arithmetic/analytical hierarchy (★ §5 top routing probe)", "DECISION", _NEW),
    T("D1.rice", "D-1", "computability", (14,), "obstruction", "rice_index_set",
      "non-trivial semantic property of programs", "[decline_boundary] (★ §6 PHASE D)", "DECLINE", _EXIST),
    T("D1.kolmogorov_incompressible", "D-1", "computability", (12, 14), "obstruction", "incompressibility",
      "string (2-part code can't beat literal)", "[decline_boundary] (★ §6)", "DECLINE", _EXIST),
    T("D1.turbulence_E0", "D-1", "descriptive-set-theory", (14,), "obstruction", "turbulence_E0",
      "classification problem reducible to E₀", "[decline_boundary] (★ §6)", "DECLINE", _EXIST),
    # D-2
    T("D2.verifier_np_ph_tfnp", "D-2", "complexity", (14, 3), "decision", "verifier_witness",
      "decision problem (poly-checkable witness / PPAD)", "verifier view (Nash↔PPAD)", "DECISION", _NEW),
    T("D2.sumcheck_arithmetization", "D-2", "complexity", (2, 7), "decision", "low_degree_identity",
      "counting / boolean formula", "sum-check (IP=PSPACE)", "DECISION", _NEW),
    T("D2.pcp_robustification", "D-2", "complexity", (8,), "normal-form", "pcp_robust",
      "NP proof", "PCP (O(1)-bit verifier) + error-correction", "DECISION", _NEW),
    T("D2.snark_stark_iop", "D-2", "complexity", (4, 8), "cert-bound", "succinct_cert",
      "computation integrity", "arkworks/plonky2 / FRI (★ §8 PHASE G — integrity cert, NOT PQC)", "EXACT", _NEW),
    T("D2.hardness_randomness", "D-2", "complexity", (7,), "cert-bound", "pseudorandom_bound",
      "BPP derandomization", "Nisan–Wigderson / IW", "DECISION", _NEW),
    # PHASE 21 (C7 re-map): the expander / spectral-gap path is M4+M7, NOT M11. λ₂ is the SDP/Rayleigh RELAXATION of
    # sparsest-cut/conductance (M4 relax+dualize), and a large gap ⇒ quasirandom by the expander mixing lemma (M7
    # structure+pseudorandomness) — a spectral CERTIFICATE of a combinatorial property, never latent-state recovery.
    T("D2.zigzag_expander", "D-2", "complexity", (4, 7), "finite-invariant", "spectral_gap_relaxation_certificate",
      "graph connectivity / conductance (SL=L)", "λ₂ relaxation (M4) + expander mixing quasirandomness (M7)", "DECISION", _NEW),
    T("D2.sos_refutation", "D-2", "proof-complexity", (4, 14), "cert-bound", "refutation_degree",
      "CNF / polynomial system unsatisfiability", "SOS/PC/Nullstellensatz refutation (merges B1.sos)", "DECISION", _NEW),
    T("D2.complexity_barriers", "D-2", "complexity", (14,), "obstruction", "barrier",
      "circuit lower-bound attempt", "natural-proofs/relativization/algebrization [decline_boundary] (★ §6)",
      "DECLINE", _EXIST),
    T("D2.gct_orbit_closure", "D-2", "complexity", (9, -1), "finite-invariant", "orbit_separation",
      "P vs NP (geometric complexity)", "GCT (current obstacle stated — UNVERIFIED, limit logged)", "DECISION",
      "UNVERIFIED(GCT representation-theoretic separation is an open obstacle — registered honestly, not buildable)"),
    T("D2.kernelization_fpt", "D-2", "complexity", (12, 2), "code-length", "kernel_size",
      "parameterized problem", "FPT instance compression", "DECISION", _NEW),
    T("D2.twin_width", "D-2", "complexity", (10,), "finite-invariant", "fo_model_checking",
      "sparse graph (bounded expansion)", "twin-width", "DECISION", _NEW),
    T("D2.fine_grained_seth", "D-2", "complexity", (14,), "obstruction", "fine_grained_barrier",
      "algorithm (SETH/3SUM/APSP)", "conditional DECLINE (blocks a specific poly speed)", "DECLINE", _NEW),
    T("D2.hott_canonicity", "D-2", "type-theory", (8, 9), "normal-form", "canonicity",
      "closed term / proof (univalence)", "cubical Agda / Arend", "EXACT", _NEW),
    T("D2.maclane_coherence", "D-2", "category-theory", (8,), "normal-form", "coherence",
      "monoidal category morphism", "Mac Lane strictification", "EXACT", _NEW),
    T("D2.nbe", "D-2", "type-theory", (8, 13), "normal-form", "nbe_normal",
      "typed term", "normalization-by-evaluation [evaluation core — §8 PHASE C]", "EXACT", _NEW),
    T("D2.zx_calculus", "D-2", "quantum", (8,), "normal-form", "zx_complete",
      "quantum circuit / monoidal morphism", "PyZX / Quantomatic", "DECISION", _NEW),
    T("D2.typecheck_decidability", "D-2", "type-theory", (3,), "decision", "typecheck_decision",
      "type (System F inhabitation = undecidable — limit stated)", "bidirectional type checking", "DECISION", _NEW),
])
