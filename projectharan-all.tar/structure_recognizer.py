"""
v27 STAGE 12 — structure recognition + LLM-offload dispatcher  ★the cross-cutting top lever★
============================================================================================
"General code" is locally structured. Underneath a piece there is often an ALGEBRAIC OBJECT
(monoid / lattice / semiring / fixpoint) and a SHAPE (a closed-form loop, a tensor/linear-algebra
kernel, a relational join, a string/regex scan, a dataflow fixpoint, an error-tolerant probabilistic
estimate). When we can RECOGNIZE that structure we can do better than re-emitting tokens:

  (a) OFFLOAD it to a sound solver — the LLM proposes a sketch/spec, a *sound* synthesizer completes
      it and a verifier PROVES it (less LLM work, higher accuracy); or
  (b) apply a CERTIFIED REWRITE — a structure-justified transform proved equivalent to the original.

★ The differentiator is the certificate, never "nicer code". ★  This module is the recognizer + the
dispatcher. It implements TWO end-to-end SOUND actions and is honest everywhere else:

  • CLOSED_FORM_LOOP → OFFLOAD to the fold solver (S7). Verified lifting: the Python loop is lifted to a
    HARAN fold, the solver returns a closed form, and we gate it by DIFFERENTIAL EQUIVALENCE against the
    *original executed code* on many inputs (★never a wrong closed form★). O(n) → O(1)/O(log n).
  • RELATIONAL_JOIN (equi-join) → CERTIFIED REWRITE to a hash join. Source-to-source, identical emit, then
    differential-equivalence-gated AND measured: O(n·m) → O(n+m). (A pure-Python win — no numpy needed.)

Every other recognized class (TENSOR_LA, STRING_REGEX, DATAFLOW_FIXPOINT, PROBABILISTIC_APPROX) is
classified honestly and routed to its future stage; with no sound action wired here it returns NONE →
the honest LLM general-generation fallback. Recognition is sound static analysis; the two actions are
gated by execution, so a misclassification can only DECLINE (NONE), never emit a wrong answer.

★ HONEST LIMITS ★: (1) only the *structured minority* of pieces is offloaded; glue stays with the LLM —
there is NO uniform speedup (Ω(N), §1.3). (2) The "LLM proposes the sketch" half needs a key/egress
(absent here, §1.6); we implement and measure the *sound completion+proof* half (the transferable part),
exactly as S9 did for the missing SIMD backend.
"""
from __future__ import annotations

import ast
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import fold_kernels as FK

# ── shape classes + algebraic objects (the unified algebra of §0.4) ─────────────────────────────────
CLOSED_FORM_LOOP = "CLOSED_FORM_LOOP"
TENSOR_LA = "TENSOR_LA"
RELATIONAL_JOIN = "RELATIONAL_JOIN"
STRING_REGEX = "STRING_REGEX"
DATAFLOW_FIXPOINT = "DATAFLOW_FIXPOINT"
PROBABILISTIC_APPROX = "PROBABILISTIC_APPROX"
NONE = "NONE"

# associative accumulator ops → (haran-op, algebra, identity)
_MONOID_BIN = {"Add": ("+", "monoid", "0"), "Mult": ("*", "monoid", "1")}
_LATTICE_FN = {"max": ("max", "lattice"), "min": ("min", "lattice")}


@dataclass
class Structure:
    kind: str
    algebra: str = "none"          # monoid | lattice | semiring | fixpoint | none
    detail: str = ""
    fn_name: str = ""
    def __str__(self):
        return f"{self.kind} (algebra={self.algebra}) — {self.detail}"


@dataclass
class Dispatch:
    status: str                    # OFFLOADED | RECOGNIZED_REWRITE | NONE
    structure: Structure = None
    certificate: str = ""
    closed_form: str = ""
    complexity: str = ""
    speedup: float = 1.0
    workload: str = ""
    detail: str = ""
    def __str__(self):
        if self.status == "OFFLOADED":
            return f"OFFLOADED → {self.closed_form} ({self.complexity}; differential-equivalence verified)"
        if self.status == "RECOGNIZED_REWRITE":
            return f"RECOGNIZED_REWRITE [{self.structure.kind}] {self.speedup:.2f}× ({self.workload}; equivalence verified)"
        return f"NONE — {self.detail} (→ LLM general generation)"


# ── parsing helpers ─────────────────────────────────────────────────────────────────────────────────
def _first_fn(source: str, fn_name: Optional[str]) -> Optional[ast.FunctionDef]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    fns = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    if fn_name:
        return next((f for f in fns if f.name == fn_name), None)
    return fns[0] if fns else None


def _names_used(node: ast.AST) -> set:
    return {n.id for n in ast.walk(node) if isinstance(n, ast.Name)}


def _has_call(fnnode: ast.AST, mod: str) -> bool:
    """True if the function calls `mod.<something>` (e.g. re.* or random.*)."""
    for n in ast.walk(fnnode):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) \
                and isinstance(n.func.value, ast.Name) and n.func.value.id == mod:
            return True
    return False


def _for_loops(fnnode: ast.AST) -> List[ast.For]:
    return [n for n in ast.walk(fnnode) if isinstance(n, ast.For)]


# ── individual structure detectors (sound, syntactic) ───────────────────────────────────────────────
@dataclass
class _AccLoop:
    var: str
    lo: str
    hi: str            # python range upper bound (EXCLUSIVE), as source
    op: str            # "+" | "*"
    algebra: str
    body: str          # the accumulated expression, source, in terms of `var`


def _closed_form_loop(fnnode: ast.FunctionDef) -> Optional[_AccLoop]:
    """`for v in range(lo,hi): acc OP= f(v)` (OP associative), acc returned. f depends on v only."""
    fors = [n for n in fnnode.body if isinstance(n, ast.For)]
    if len(_for_loops(fnnode)) != 1 or len(fors) != 1:
        return None
    loop = fors[0]
    if not (isinstance(loop.iter, ast.Call) and isinstance(loop.iter.func, ast.Name)
            and loop.iter.func.id == "range" and isinstance(loop.target, ast.Name)):
        return None
    args = loop.iter.args
    if len(args) == 1:
        lo, hi = "0", ast.unparse(args[0])
    elif len(args) == 2:
        lo, hi = ast.unparse(args[0]), ast.unparse(args[1])
    else:
        return None                              # step != 1 → not lifted here (honest)
    if len(loop.body) != 1:
        return None
    stmt = loop.body[0]
    var = loop.target.id
    op = algebra = body = None
    if isinstance(stmt, ast.AugAssign) and isinstance(stmt.target, ast.Name):
        b = _MONOID_BIN.get(type(stmt.op).__name__)
        if b:
            op, algebra, body = b[0], b[1], ast.unparse(stmt.value)
    elif isinstance(stmt, ast.Assign) and len(stmt.targets) == 1 and isinstance(stmt.targets[0], ast.Name):
        acc = stmt.targets[0].id
        v = stmt.value
        if isinstance(v, ast.BinOp) and type(v.op).__name__ in _MONOID_BIN:        # acc = acc + f(v)
            b = _MONOID_BIN[type(v.op).__name__]
            other = None
            if isinstance(v.left, ast.Name) and v.left.id == acc:
                other = v.right
            elif isinstance(v.right, ast.Name) and v.right.id == acc:
                other = v.left
            if other is not None:
                op, algebra, body = b[0], b[1], ast.unparse(other)
    if op is None or body is None:
        return None
    # f(v) must depend only on the loop var (and constants/params) — NOT the accumulator / external state
    if var not in _names_used(ast.parse(body, mode="eval")):
        return None
    return _AccLoop(var=var, lo=lo, hi=hi, op=op, algebra=algebra, body=body)


@dataclass
class _Join:
    a_iter: str
    b_iter: str
    a_var: str
    b_var: str
    key_a: str
    key_b: str
    emit: str
    out: str


def _equi_join(fnnode: ast.FunctionDef) -> Optional[_Join]:
    """`for a in A: for b in B: if <a-key> == <b-key>: out.append(<emit>)` — a canonical equi-join."""
    for outer in [n for n in ast.walk(fnnode) if isinstance(n, ast.For)]:
        if not (isinstance(outer.target, ast.Name) and isinstance(outer.iter, ast.Name)):
            continue
        inners = [n for n in outer.body if isinstance(n, ast.For)]
        if len(inners) != 1:
            continue
        inner = inners[0]
        if not (isinstance(inner.target, ast.Name) and isinstance(inner.iter, ast.Name)):
            continue
        if len(inner.body) != 1 or not isinstance(inner.body[0], ast.If):
            continue
        iff = inner.body[0]
        t = iff.test
        if not (isinstance(t, ast.Compare) and len(t.ops) == 1 and isinstance(t.ops[0], ast.Eq)):
            continue                             # single equality only (equi-join) — else honest decline
        if not (len(iff.body) == 1 and isinstance(iff.body[0], ast.Expr)
                and isinstance(iff.body[0].value, ast.Call)):
            continue
        call = iff.body[0].value
        if not (isinstance(call.func, ast.Attribute) and call.func.attr == "append"
                and isinstance(call.func.value, ast.Name) and len(call.args) == 1):
            continue
        a_var, b_var = outer.target.id, inner.target.id
        left, right = t.left, t.comparators[0]
        ln, rn = _names_used(left), _names_used(right)
        if a_var in ln and b_var in rn:
            key_a, key_b = ast.unparse(left), ast.unparse(right)
        elif b_var in ln and a_var in rn:
            key_a, key_b = ast.unparse(right), ast.unparse(left)
        else:
            continue
        return _Join(a_iter=outer.iter.id, b_iter=inner.iter.id, a_var=a_var, b_var=b_var,
                     key_a=key_a, key_b=key_b, emit=ast.unparse(call.args[0]), out=call.func.value.id)
    return None


def _tensor_la(fnnode: ast.FunctionDef) -> bool:
    """≥2 nested loops with a multiply-accumulate `C[..] += A[..]*B[..]` (semiring ⊕/⊗)."""
    for n in ast.walk(fnnode):
        if isinstance(n, ast.AugAssign) and type(n.op).__name__ == "Add" \
                and isinstance(n.target, ast.Subscript) and isinstance(n.value, ast.BinOp) \
                and type(n.value.op).__name__ == "Mult":
            depth = sum(1 for p in ast.walk(fnnode) if isinstance(p, ast.For))
            if depth >= 2:
                return True
    return False


def _dataflow_fixpoint(fnnode: ast.FunctionDef) -> bool:
    """A `while`-to-convergence (changed flag / worklist) — a lattice fixpoint iteration."""
    for n in ast.walk(fnnode):
        if isinstance(n, ast.While):
            cond_names = {x.lower() for x in _names_used(n.test)}
            if any(k in cond_names for k in ("changed", "change", "dirty", "worklist", "queue", "work")):
                return True
            if isinstance(n.test, ast.Name):              # while worklist:
                return True
    return False


# ── the recognizer ──────────────────────────────────────────────────────────────────────────────────
def recognize(source: str, fn_name: Optional[str] = None) -> Structure:
    """Classify a function into a shape + underlying algebra by sound static analysis. Precise structural
    shapes win over weak keyword signals; nothing matched ⇒ NONE (honest)."""
    fn = _first_fn(source, fn_name)
    if fn is None:
        return Structure(NONE, detail="no parseable function")
    name = fn.name
    if _tensor_la(fn):
        return Structure(TENSOR_LA, "semiring", "multiply-accumulate over nested loops", name)
    j = _equi_join(fn)
    if j is not None:
        return Structure(RELATIONAL_JOIN, "semiring", f"equi-join on {j.key_a}=={j.key_b}", name)
    acc = _closed_form_loop(fn)
    if acc is not None:
        return Structure(CLOSED_FORM_LOOP, acc.algebra,
                         f"reduce('{acc.op}', f({acc.var})) over range({acc.lo},{acc.hi})", name)
    if _dataflow_fixpoint(fn):
        return Structure(DATAFLOW_FIXPOINT, "fixpoint", "while-to-convergence (lattice fixpoint)", name)
    if _has_call(fn, "re") or any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                                  and n.func.attr in ("match", "search", "findall", "sub", "split")
                                  for n in ast.walk(fn)):
        return Structure(STRING_REGEX, "none", "regex / string scan", name)
    if _has_call(fn, "random"):
        return Structure(PROBABILISTIC_APPROX, "none", "random sampling (error-tolerant estimate)", name)
    return Structure(NONE, "none", "no provable algebraic/shape structure", name)


# ── action 1: OFFLOAD a closed-form loop to the fold solver (verified lifting) ──────────────────────
# a pure, side-effect-free builtin set: arithmetic + collections, but NO __import__ / open / eval / exec
# (so executing the user's analyzed code for the equivalence gate cannot touch files, the network, or import).
_SAFE_BUILTINS = {"range": range, "min": min, "max": max, "abs": abs, "sum": sum, "pow": pow, "len": len,
                  "list": list, "dict": dict, "tuple": tuple, "set": set, "frozenset": frozenset,
                  "enumerate": enumerate, "sorted": sorted, "reversed": reversed, "zip": zip,
                  "map": map, "filter": filter, "bool": bool, "int": int, "float": float, "str": str,
                  "round": round, "divmod": divmod}
_SAMPLE_N = [1, 2, 3, 5, 8, 13, 20, 37, 64]


def _make_callable(source: str, name: str):
    ns: dict = {}
    exec(compile(source, "<recognize>", "exec"), {"__builtins__": _SAFE_BUILTINS}, ns)  # noqa: S102
    return ns.get(name)


def _offload_closed_form(source: str, fn: ast.FunctionDef, acc: _AccLoop) -> Dispatch:
    struct = Structure(CLOSED_FORM_LOOP, acc.algebra, f"reduce('{acc.op}', f({acc.var}))", fn.name)
    if len(fn.args.args) != 1:
        return Dispatch(NONE, struct, detail="closed-form lift supports single-parameter functions here")
    if acc.op != "+":          # HARAN's fold is summation (Σ); a product/other monoid is NOT representable
        return Dispatch(NONE, struct, detail=f"'{acc.op}'-accumulation is not a Σ-fold (the solver sums) "
                        "→ LLM fallback (sound: not lifted to a wrong summation)")
    param = fn.args.args[0].arg
    # f(k) must depend ONLY on the loop var (so the fold upper bound can be a clean fresh symbol)
    body_names = _names_used(ast.parse(acc.body, mode="eval"))
    if body_names - {acc.var}:
        return Dispatch(NONE, struct, detail=f"accumulated expr references {body_names - {acc.var}} "
                        "(not a pure f(k)) — outside the single-symbol fold lift here")
    # lower bound must be a concrete integer literal (the common Σ_{c}^{·} case)
    try:
        lo_val = int(eval(compile(ast.parse(acc.lo, mode="eval"), "<lo>", "eval"), {"__builtins__": {}}))  # noqa: S307
    except Exception:  # noqa: BLE001
        return Dispatch(NONE, struct, detail=f"non-constant lower bound `{acc.lo}` — not lifted here")
    try:
        ref = _make_callable(source, fn.name)
        hi_fn = eval(compile(f"lambda {param}: ({acc.hi})", "<hi>", "eval"), {"__builtins__": _SAFE_BUILTINS})  # noqa: S307
    except Exception as e:  # noqa: BLE001
        return Dispatch(NONE, struct, detail=f"could not build the equivalence gate ({type(e).__name__})")
    if ref is None:
        return Dispatch(NONE, struct, detail="original function not found after exec")
    # ★ lift to a CLEAN-SYMBOL fold `lo..u` (fold_kernels folds these correctly; arithmetic bounds it does
    #   NOT — so we never emit one). HARAN `a..b` is INCLUSIVE Σ; Python range(lo,hi) is Σ_{lo}^{hi-1},
    #   so the matching upper symbol value is u = hi-1. The gate is the sole soundness authority.
    import sympy
    u = sympy.Symbol("u")
    haran = f"fn g(u: Nat) -> Nat {{ fold {acc.var} in {lo_val}..u {{ {acc.body} }} }}"
    verdict = FK.fold_certificate(haran)
    if verdict.status != "FOLDED":
        return Dispatch(NONE, struct, detail=f"fold solver did not close this form ({verdict.status}: "
                        f"{verdict.reason}) → LLM fallback")
    try:
        cf = sympy.sympify(verdict.closed_form)
    except Exception:  # noqa: BLE001
        return Dispatch(NONE, struct, detail="closed form not interpretable → LLM fallback")
    ok = checked = 0
    for val in _SAMPLE_N:
        try:
            want = ref(val)
            n_eval = int(hi_fn(val)) - 1            # Python range exclusivity → inclusive fold upper
        except Exception:  # noqa: BLE001
            continue
        if n_eval < lo_val:                          # empty range → skip (closed form may extrapolate)
            continue
        checked += 1
        if abs(float(cf.subs(u, n_eval)) - float(want)) <= 1e-6:
            ok += 1
    if checked < 5 or ok != checked:
        return Dispatch(NONE, struct, detail=f"closed form not equivalence-verified ({ok}/{checked}) → "
                        "LLM fallback (sound: a wrong form is never emitted)")
    # present the closed form in terms of the ORIGINAL parameter: cf(u := hi(param)-1)
    try:
        psym = sympy.Symbol(param)
        cf_orig = str(sympy.simplify(cf.subs(u, sympy.sympify(acc.hi.replace(param, param)) - 1)))
    except Exception:  # noqa: BLE001
        cf_orig = f"{verdict.closed_form} [with u = ({acc.hi})-1]"
    cert = (f"OFFLOAD certificate: general loop `{fn.name}` lifted to fold `{lo_val}..u` → {verdict.kernel} "
            f"closed form {verdict.closed_form} ({verdict.complexity}); differential-equivalence verified on "
            f"{checked}/{checked} inputs vs the ORIGINAL executed code (never a wrong closed form). The fold "
            f"solver + the gate are the authority; the LLM only proposed the sketch.")
    return Dispatch("OFFLOADED", struct, certificate=cert, closed_form=cf_orig,
                    complexity=verdict.complexity, detail="offloaded to fold solver")


# ── action 2: CERTIFIED REWRITE of an equi-join to a hash join (measured) ───────────────────────────
def _synth_hash_join(j: _Join) -> str:
    # `__dd` (collections.defaultdict) is injected into the exec globals — the restricted builtins
    # deliberately have no __import__, so we never `import` inside the synthesized code.
    return (
        f"def __hj({j.a_iter}, {j.b_iter}):\n"
        f"    __idx = __dd(list)\n"
        f"    for {j.b_var} in {j.b_iter}:\n"
        f"        __idx[{j.key_b}].append({j.b_var})\n"
        f"    {j.out} = []\n"
        f"    for {j.a_var} in {j.a_iter}:\n"
        f"        for {j.b_var} in __idx.get({j.key_a}, []):\n"
        f"            {j.out}.append({j.emit})\n"
        f"    return {j.out}\n"
    )


def _rewrite_join(source: str, fn: ast.FunctionDef, j: _Join, n: int = 3000) -> Dispatch:
    struct = Structure(RELATIONAL_JOIN, "semiring", f"equi-join {j.key_a}=={j.key_b}", fn.name)
    # only the tuple/int-keyed shape is auto-sampleable here; otherwise classify but decline the rewrite
    if not (j.key_a.startswith(j.a_var) and j.key_b.startswith(j.b_var)):
        return Dispatch(NONE, struct, detail="join key shape not auto-sampleable here (honest)")
    try:
        import collections
        orig = _make_callable(source, fn.name)
        hj_ns: dict = {}
        hj_globals = {"__builtins__": _SAFE_BUILTINS, "__dd": collections.defaultdict}
        exec(compile(_synth_hash_join(j), "<hashjoin>", "exec"), hj_globals, hj_ns)  # noqa: S102
        hj = hj_ns["__hj"]
    except Exception as e:  # noqa: BLE001
        return Dispatch(NONE, struct, detail=f"could not build/exec the rewrite ({type(e).__name__})")
    import random
    rng = random.Random(0xC0FFEE)
    # ★ differential-equivalence gate ★ on several random small relations (tuples of ints)
    for _ in range(20):
        A = [(rng.randint(0, 8), rng.randint(0, 99)) for _ in range(rng.randint(0, 12))]
        B = [(rng.randint(0, 8), rng.randint(0, 99)) for _ in range(rng.randint(0, 12))]
        try:
            if orig(list(A), list(B)) != hj(list(A), list(B)):
                return Dispatch(NONE, struct, detail="hash-join not equivalent to the original on a sample "
                                "(compound/non-canonical body) — rewrite declined (sound)")
        except Exception as e:  # noqa: BLE001
            return Dispatch(NONE, struct, detail=f"equivalence gate could not run ({type(e).__name__})")
    # measured speedup on a sizeable workload (O(n·m) nested loop vs O(n+m) hash join)
    bigA = [(rng.randint(0, n // 4), rng.randint(0, 10 ** 6)) for _ in range(n)]
    bigB = [(rng.randint(0, n // 4), rng.randint(0, 10 ** 6)) for _ in range(n)]
    t = time.perf_counter(); r1 = orig(list(bigA), list(bigB)); s_naive = time.perf_counter() - t
    t = time.perf_counter(); r2 = hj(list(bigA), list(bigB)); s_hash = time.perf_counter() - t
    if r1 != r2:
        return Dispatch(NONE, struct, detail="output mismatch on the measured workload — rewrite rejected")
    speedup = s_naive / s_hash if s_hash > 0 else 1.0
    workload = f"equi-join of two {n}-row relations on a {n // 4}-cardinality key"
    if speedup < 1.1:
        return Dispatch(NONE, struct, speedup=speedup, workload=workload,
                        detail=f"measured {speedup:.2f}× (<1.1×) — not a win, reverted (§1.10)")
    cert = (f"REWRITE certificate: nested-loop equi-join on {j.key_a}=={j.key_b} → hash join "
            f"(O(n·m) → O(n+m)); differential-equivalence verified on 20 random relations + the measured "
            f"workload; identical output (never a wrong transform). Measured {speedup:.2f}× on {workload}.")
    return Dispatch("RECOGNIZED_REWRITE", struct, certificate=cert, speedup=speedup, workload=workload,
                    detail="certified hash-join rewrite")


# ── the dispatcher ──────────────────────────────────────────────────────────────────────────────────
def dispatch(source: str, fn_name: Optional[str] = None) -> Dispatch:
    """Recognize the structure and take the sound action: OFFLOAD (closed form) / REWRITE (hash join) /
    NONE (honest LLM fallback). A misclassification can only DECLINE — the execution gates never let a
    wrong answer through."""
    fn = _first_fn(source, fn_name)
    if fn is None:
        return Dispatch(NONE, Structure(NONE, detail="no parseable function"), detail="no function")
    try:
        if _tensor_la(fn):
            return Dispatch(NONE, Structure(TENSOR_LA, "semiring", "multiply-accumulate", fn.name),
                            detail="tensor/LA recognized → equality-saturation path is S17 (not wired here)")
        j = _equi_join(fn)
        if j is not None:
            return _rewrite_join(source, fn, j)
        acc = _closed_form_loop(fn)
        if acc is not None:
            return _offload_closed_form(source, fn, acc)
        s = recognize(source, fn_name)
        if s.kind == DATAFLOW_FIXPOINT:
            return Dispatch(NONE, s, detail="dataflow fixpoint recognized → abstract-interpretation path "
                            "(S16/S17), not offloaded here")
        return Dispatch(NONE, s, detail=s.detail)
    except Exception as e:  # noqa: BLE001 — recognition/offload must never crash the pipeline
        return Dispatch(NONE, Structure(NONE, detail=f"recognizer error: {type(e).__name__}"),
                        detail="recognizer raised — safe NONE (LLM fallback)")
